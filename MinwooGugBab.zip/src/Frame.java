import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Frame {
    public static void main(String[] args) {
        JFrame frame = new JFrame();
        JPanel panel = new JPanel();
        JLabel label = new JLabel("Some Text");
        JButton btn1 = new JButton("Click me!!");
        JButton btn2 = new JButton("Exit");
        JTextArea textArea = new JTextArea();
        JTextField textField = new JTextField(200);
        JPanel btnPanel = new JPanel();
        //JTextArea: 여러 줄, JTextField: 제한된 텍스트
        //frame: 시작할 때 하나의 툴
        //panel: 안에 여러 가지 집어 넣는 것 -> 기능 같은 거를 나눠서 넣음 (과부하 방지)

        //BorderLayout(): 원하는 곳에 컴포넌트를 위치시키는 것
        panel.setLayout(new BorderLayout());

        btnPanel.add(btn1);
        btnPanel.add(btn2);
        panel.add(label, BorderLayout.NORTH);
        panel.add(btnPanel, BorderLayout.WEST);
        panel.add(textArea, BorderLayout.CENTER);

        btn1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                //textArea.append("You are amazing\n");
                label.setText(textArea.getText());
            }
        });

        btn2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                System.exit(0);
            }
        });

        //패널은 직접 집어넣어야 함
        frame.add(panel);

        //프레임 크기 건드릴 수 있나?
        frame.setResizable(false);
        //프레임이 보이게
        frame.setVisible(true);
        //평소의 메인 사이즈
        frame.setPreferredSize(new Dimension(840, 840/12*9));
        //시작 사이즈
        frame.setSize(840, 840/12*9);
        //가운데에서 시작
        frame.setLocationRelativeTo(null);
        //종료시 프로그램 총 종료
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
