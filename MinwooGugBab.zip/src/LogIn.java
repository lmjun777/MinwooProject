import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LogIn extends JFrame {
    public LogIn() {
        JPanel panel = new JPanel();
        JLabel label = new JLabel("ID : ");
        JLabel pswrd = new JLabel("Password : ");
        JTextField textID = new JTextField(10);
        JPasswordField textPass = new JPasswordField(10);
        JButton logBtn = new JButton("Login");

        panel.add(label);
        panel.add(textID);
        panel.add(pswrd);
        panel.add(textPass);
        panel.add(logBtn);

        logBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                String id = "Dan";
                String pass = "1234";

                if (id.equals(textID.getText()) && pass.equals(textPass.getText())) {
                    JOptionPane.showMessageDialog(null, "You have logged in successfully");
                } else {
                    JOptionPane.showMessageDialog(null, "You have failed to log in");
                }
            }
        });
        add(panel);

        setVisible(true);
        setSize(600, 400);
        setLocationRelativeTo(null);
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public static void main(String[] args) {
        new LogIn();
    }
}
