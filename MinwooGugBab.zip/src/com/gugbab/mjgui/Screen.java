package com.gugbab.mjgui;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

public class Screen extends JFrame {
    private JPanel panelTop;
    private JPanel panelLeft;
    private JPanel panelRight;
    private JList listPeople;
    private JTextField textName;
    private JTextField textEmail;
    private JTextField textPhoneNumber;
    private JButton buttonNew;
    private JButton buttonSave;
    private JTextField textDateOfBirth;
    private JLabel labelAge;
    private JPanel panelMain;
    private ArrayList<Person> people;
    private DefaultListModel listPeopleModel;

    Screen() {
        super("My First GUI Project");
        this.setContentPane(this.panelMain);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(600, 400);
        this.setPreferredSize(new Dimension(600, 400));
        this.setLocationRelativeTo(null);
        this.setResizable(false);
        this.pack();
        people = new ArrayList<Person>();
        listPeopleModel = new DefaultListModel();
        listPeople.setModel(listPeopleModel);
        buttonSave.setEnabled(false);

        buttonNew.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                buttonNewClick(actionEvent);
            }
        });

        buttonSave.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                buttonSaveClick(actionEvent);
            }
        });

        listPeople.addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent listSelectionEvent) {
                listPeopleSelection(listSelectionEvent);
            }
        });
    }

    public void buttonNewClick(ActionEvent e) {
        Person person = new Person(
                textName.getText(),
                textEmail.getText(),
                textPhoneNumber.getText(),
                textDateOfBirth.getText()
        );
        people.add(person);
        refreshPeopleList();
    }

    public void buttonSaveClick(ActionEvent e) {
        int personNumber = listPeople.getSelectedIndex();
        if (personNumber >= 0) {
            Person person = people.get(personNumber);
            person.setName(textName.getText());
            person.setEmail(textEmail.getText());
            person.setPhoneNumber(textPhoneNumber.getText());
            person.setDateOfBirth(textDateOfBirth.getText());
            refreshPeopleList();
        }
    }

    public void listPeopleSelection(ListSelectionEvent e) {
        int personNumber = listPeople.getSelectedIndex();
        if (personNumber >= 0) {
            Person person = people.get(personNumber);
            textName.setText(person.getName());
            textEmail.setText(person.getEmail());
            textPhoneNumber.setText(person.getPhoneNumber());
            textDateOfBirth.setText(person.getDateOfBirth().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")));
            labelAge.setText(Integer.toString(person.getAge())+" years");
            buttonSave.setEnabled(true);
        } else {
            buttonSave.setEnabled(false);
        }
    }

    public void refreshPeopleList() {
        listPeopleModel.removeAllElements();
        System.out.println("Removing all people from list");
        for (Person person: people) {
            //'sout' + Enter << System.out.println();
            System.out.println("Adding person to list: "+person.getName());
            listPeopleModel.addElement(person.getName());
        }
    }

    public void addPerson(Person person) {
        people.add(person);
        refreshPeopleList();
    }

    public static void main(String[] args) {
        Screen screen = new Screen();
        screen.setVisible(true);

        Person sheldon = new Person("Lee Min Jun", "lmj@gmail.com", "555 0001", "03/04/1995");
        Person raj = new Person("Gu hwal Geum", "ghg50@gmail.com", "555 0003", "01/01/1900");
        Person bernadette = new Person("Caffe One One", "coo11@naver.com", "555 1234", "08/08/1988");
        Person leonard = new Person("Today Date", "td825@daum.com", "345 1212", "17/05/1980");

        screen.addPerson(sheldon);
        screen.addPerson(raj);
        screen.addPerson(bernadette);
        screen.addPerson(leonard);
    }
}
